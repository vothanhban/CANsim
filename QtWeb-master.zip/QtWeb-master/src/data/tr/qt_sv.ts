<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sv">
<context>
    <name>CloseButton</name>
    <message>
        <location filename="../src/gui/widgets/qtabbar.cpp" line="+2251"/>
        <source>Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <location filename="../src/network/socket/qabstractsocket.cpp" line="+868"/>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="+615"/>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="+657"/>
        <location line="+26"/>
        <source>Host not found</source>
        <translation>Värden hittades inte</translation>
    </message>
    <message>
        <location line="+50"/>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="+3"/>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="+4"/>
        <source>Connection refused</source>
        <translation>Anslutningen nekades</translation>
    </message>
    <message>
        <location line="+141"/>
        <source>Connection timed out</source>
        <translation type="unfinished">Tidsgränsen för anslutning överstegs</translation>
    </message>
    <message>
        <location line="-547"/>
        <location line="+787"/>
        <location line="+208"/>
        <source>Operation on socket is not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+137"/>
        <source>Socket operation timed out</source>
        <translation>Tidsgräns för uttagsåtgärd överstegs</translation>
    </message>
    <message>
        <location line="+380"/>
        <source>Socket is not connected</source>
        <translation>Uttaget är inte anslutet</translation>
    </message>
    <message>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="-8"/>
        <source>Network unreachable</source>
        <translation type="unfinished">Nätverket är inte nåbart</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/gui/accessible/qaccessibleobject.cpp" line="+376"/>
        <source>Activate</source>
        <translation>Aktivera</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qdialog.cpp" line="+597"/>
        <source>What&apos;s This?</source>
        <translation>Vad är det här?</translation>
    </message>
    <message>
        <location line="-115"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <location filename="../src/gui/dialogs/qmessagebox.cpp" line="+1866"/>
        <location line="+464"/>
        <location filename="../src/gui/widgets/qdialogbuttonbox.cpp" line="+561"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/gui/widgets/qdialogbuttonbox.cpp" line="+3"/>
        <source>Save</source>
        <translation type="unfinished">Spara</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Spara</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cancel</source>
        <translation type="unfinished">Avbryt</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Avbryt</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Close</source>
        <translation type="unfinished">Stäng</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Stäng</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Apply</source>
        <translation>Verkställ</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Reset</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Don&apos;t Save</source>
        <translation>Spara inte</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Discard</source>
        <translation>Förkasta</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Yes to &amp;All</source>
        <translation>Ja till &amp;alla</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>N&amp;o to All</source>
        <translation>N&amp;ej till alla</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Save All</source>
        <translation>Spara alla</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Abort</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Retry</source>
        <translation>Försök igen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Ignore</source>
        <translation>Ignorera</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Restore Defaults</source>
        <translation>Återställ standardvärden</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Close without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-27"/>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <location filename="../src/gui/dialogs/qerrormessage.cpp" line="+192"/>
        <source>Debug Message:</source>
        <translation>Felsökningsmeddelande:</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning:</source>
        <translation>Varning:</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Fatal Error:</source>
        <translation>Ödesdigert fel:</translation>
    </message>
    <message>
        <location line="+193"/>
        <source>&amp;Show this message again</source>
        <translation>&amp;Visa detta meddelande igen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <location filename="../src/corelib/io/qfile.cpp" line="+708"/>
        <location line="+141"/>
        <source>Destination file exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-108"/>
        <source>Cannot remove source file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+120"/>
        <source>Cannot open %1 for input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Cannot open for output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Failure to write block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Cannot create %1 for output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <location filename="../src/network/access/qftp.cpp" line="+826"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+683"/>
        <source>Not connected</source>
        <translation>Inte ansluten</translation>
    </message>
    <message>
        <location line="+65"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+65"/>
        <source>Host %1 not found</source>
        <translation>Värden %1 hittades inte</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+4"/>
        <source>Connection refused to host %1</source>
        <translation>Anslutningen till värden %1 vägrades</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Connection timed out to host %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+104"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+102"/>
        <location line="+1451"/>
        <source>Connected to host %1</source>
        <translation>Ansluten till värden %1</translation>
    </message>
    <message>
        <location line="+219"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-1290"/>
        <source>Connection refused for data connection</source>
        <translation>Anslutning vägrades för dataanslutning</translation>
    </message>
    <message>
        <location line="+178"/>
        <location line="+29"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+195"/>
        <location line="+728"/>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <location line="+889"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+77"/>
        <source>Connecting to host failed:
%1</source>
        <translation>Anslutning till värden misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Login failed:
%1</source>
        <translation>Inloggning misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Listing directory failed:
%1</source>
        <translation>Listning av katalogen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Changing directory failed:
%1</source>
        <translation>Byte av katalog misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Downloading file failed:
%1</source>
        <translation>Nedladdningen av filen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Uploading file failed:
%1</source>
        <translation>Uppladdningen av filen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Removing file failed:
%1</source>
        <translation>Borttagning av filen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Creating directory failed:
%1</source>
        <translation>Skapandet av katalogen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Removing directory failed:
%1</source>
        <translation>Borttagning av katalogen misslyckades: 
%1</translation>
    </message>
    <message>
        <location line="+28"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+25"/>
        <location line="+250"/>
        <source>Connection closed</source>
        <translation>Anslutningen stängd</translation>
    </message>
    <message>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-11"/>
        <source>Host %1 found</source>
        <translation>Värden %1 hittades</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Connection to %1 closed</source>
        <translation>Anslutningen till %1 stängdes</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Host found</source>
        <translation>Värden hittades</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Connected to host</source>
        <translation>Ansluten till värden</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <location filename="../src/network/kernel/qhostinfo_p.h" line="+183"/>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <location filename="../src/network/kernel/qhostinfo_unix.cpp" line="+178"/>
        <location line="+9"/>
        <location line="+64"/>
        <location line="+31"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="+180"/>
        <location line="+9"/>
        <location line="+40"/>
        <location line="+27"/>
        <source>Host not found</source>
        <translation>Värden hittades inte</translation>
    </message>
    <message>
        <location line="-44"/>
        <location line="+39"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="-34"/>
        <location line="+29"/>
        <source>Unknown address type</source>
        <translation>Okänd adresstyp</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="-19"/>
        <location line="+27"/>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="+365"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1209"/>
        <location line="+820"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+1160"/>
        <location line="+567"/>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
    <message>
        <location line="-568"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="-370"/>
        <source>Request aborted</source>
        <translation>Begäran avbröts</translation>
    </message>
    <message>
        <location line="+579"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+381"/>
        <source>No server set to connect to</source>
        <translation>Ingen server inställd att ansluta till</translation>
    </message>
    <message>
        <location line="+164"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+56"/>
        <source>Wrong content length</source>
        <translation>Fel innehållslängd</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+4"/>
        <source>Server closed connection unexpectedly</source>
        <translation>Servern stängde oväntat anslutningen</translation>
    </message>
    <message>
        <location line="+179"/>
        <source>Unknown authentication method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+183"/>
        <source>Error writing response to device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+876"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+38"/>
        <source>Connection refused</source>
        <translation>Anslutningen nekades</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="-304"/>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="-4"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+3"/>
        <source>Host %1 not found</source>
        <translation>Värden %1 hittades inte</translation>
    </message>
    <message>
        <location line="+20"/>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+10"/>
        <location line="+19"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+3"/>
        <source>HTTP request failed</source>
        <translation>HTTP-begäran misslyckades</translation>
    </message>
    <message>
        <location line="+73"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+69"/>
        <source>Invalid HTTP response header</source>
        <translation>Ogiltig HTTP-svarshuvud</translation>
    </message>
    <message>
        <location line="+125"/>
        <location line="+48"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+40"/>
        <location line="+47"/>
        <source>Invalid HTTP chunked body</source>
        <translation>Ogiltig HTTP chunked body</translation>
    </message>
    <message>
        <location filename="../src/qt3support/network/q3http.cpp" line="+294"/>
        <source>Host %1 found</source>
        <translation>Värden %1 hittades</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Connected to host %1</source>
        <translation>Ansluten till värden %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Connection to %1 closed</source>
        <translation>Anslutningen till %1 stängdes</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Host found</source>
        <translation>Värden hittades</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Connected to host</source>
        <translation>Ansluten till värd</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="-22"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+3"/>
        <source>Connection closed</source>
        <translation>Anslutningen stängd</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="-135"/>
        <source>Proxy authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-138"/>
        <source>Connection refused (or timed out)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+6"/>
        <source>Proxy requires authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Host requires authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Data corrupted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unknown protocol specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>SSL handshake failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="-89"/>
        <source>Did not receive HTTP response from proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Error parsing authentication request from proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Proxy denied connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Error communicating with HTTP proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Proxy server not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy connection refused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy server connection timed out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy connection closed prematurely</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <location filename="../src/corelib/global/qglobal.cpp" line="+1869"/>
        <source>Permission denied</source>
        <translation>Åtkomst nekad</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Too many open files</source>
        <translation>För många öppna filer</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>No such file or directory</source>
        <translation>Ingen sådan fil eller katalog</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>No space left on device</source>
        <translation>Inget ledigt utrymme på enheten</translation>
    </message>
    <message>
        <location filename="../src/corelib/io/qiodevice.cpp" line="+1536"/>
        <source>Unknown error</source>
        <translation>Okänt fel</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <location filename="../src/gui/widgets/qlineedit.cpp" line="+2680"/>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Cu&amp;t</source>
        <translation>Klipp &amp;ut</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/qaccessiblemenu.cpp" line="+157"/>
        <location line="+225"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location line="-224"/>
        <location line="+225"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location line="-223"/>
        <location line="+225"/>
        <location line="+51"/>
        <source>Execute</source>
        <translation>Kör</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <location filename="../src/gui/dialogs/qmessagebox.cpp" line="-1111"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location line="-853"/>
        <location line="+852"/>
        <location filename="../src/gui/dialogs/qmessagebox.h" line="-52"/>
        <location line="+8"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qprogressdialog.cpp" line="+182"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/simplewidgets.cpp" line="-8"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../src/gui/kernel/qkeysequence.cpp" line="+373"/>
        <source>Space</source>
        <translation>Mellanslag</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Backtab</source>
        <translation>Backtab</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Backspace</source>
        <translation>Backsteg</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Return</source>
        <translation>Return</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Print</source>
        <translation>Print</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>SysReq</source>
        <translation>SysReq</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>End</source>
        <translation>End</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Up</source>
        <translation>Upp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Down</source>
        <translation>Ned</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>CapsLock</source>
        <translation>CapsLock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>NumLock</source>
        <translation>NumLock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ScrollLock</source>
        <translation>ScrollLock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Back</source>
        <translation>Bakåt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Forward</source>
        <translation>Framåt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Refresh</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Down</source>
        <translation>Sänk volym</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Mute</source>
        <translation>Volym tyst</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Up</source>
        <translation>Höj volym</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Boost</source>
        <translation>Förstärk bas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Up</source>
        <translation>Höj bas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Down</source>
        <translation>Sänk bas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Treble Up</source>
        <translation>Höj diskant</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Treble Down</source>
        <translation>Sänk diskant</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Play</source>
        <translation>Media spela upp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Stop</source>
        <translation>Media stopp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Previous</source>
        <translation>Media föregående</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Next</source>
        <translation>Media nästa</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Record</source>
        <translation>Media spela in</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Favorites</source>
        <translation>Favoriter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Standby</source>
        <translation>Avvakta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open URL</source>
        <translation>Öppna url</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch Mail</source>
        <translation>Starta e-post</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch Media</source>
        <translation>Starta media</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (0)</source>
        <translation>Starta (0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (1)</source>
        <translation>Starta (1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (2)</source>
        <translation>Starta (2)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (3)</source>
        <translation>Starta (3)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (4)</source>
        <translation>Starta (4)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (5)</source>
        <translation>Starta (5)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (6)</source>
        <translation>Starta (6)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (7)</source>
        <translation>Starta (7)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (8)</source>
        <translation>Starta (8)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (9)</source>
        <translation>Starta (9)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (A)</source>
        <translation>Starta (A)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (B)</source>
        <translation>Starta (B)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (C)</source>
        <translation>Starta (C)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (D)</source>
        <translation>Starta (D)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (E)</source>
        <translation>Starta (E)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (F)</source>
        <translation>Starta (F)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Print Screen</source>
        <translation>Print Screen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page Up</source>
        <translation>Page Up</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page Down</source>
        <translation>Page Down</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Caps Lock</source>
        <translation>Caps Lock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Num Lock</source>
        <translation>Num Lock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Number Lock</source>
        <translation>Number Lock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Scroll Lock</source>
        <translation>Scroll Lock</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Insert</source>
        <translation>Insert</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>System Request</source>
        <translation>System Request</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Select</source>
        <translation>Välj</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Context1</source>
        <translation>Sammanhang1</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context2</source>
        <translation>Sammanhang2</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context3</source>
        <translation>Sammanhang3</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context4</source>
        <translation>Sammanhang4</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Call</source>
        <translation>Ring upp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Hangup</source>
        <translation>Lägg på</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Flip</source>
        <translation>Vänd</translation>
    </message>
    <message>
        <location line="+527"/>
        <location line="+122"/>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <location line="-121"/>
        <location line="+125"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location line="-124"/>
        <location line="+122"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location line="-121"/>
        <location line="+117"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
    <message>
        <location line="-720"/>
        <source>Home Page</source>
        <translation>Hemsida</translation>
    </message>
</context>
<context>
    <name>QTextControl</name>
    <message>
        <location filename="../src/gui/text/qtextcontrol.cpp" line="+1973"/>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Cu&amp;t</source>
        <translation>Klipp u&amp;t</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Copy &amp;Link Location</source>
        <translation>Kopiera &amp;länkplats</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/simplewidgets.cpp" line="+254"/>
        <location line="+6"/>
        <source>Press</source>
        <translation>Tryck</translation>
    </message>
    <message>
        <location line="-4"/>
        <location line="+8"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <location filename="../src/gui/util/qundogroup.cpp" line="+386"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Redo</source>
        <translation>Gör om</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <location filename="../src/gui/util/qundoview.cpp" line="+101"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <location filename="../src/gui/util/qundostack.cpp" line="+834"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Redo</source>
        <translation>Gör om</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <location filename="../src/gui/kernel/qwhatsthis.cpp" line="+522"/>
        <source>What&apos;s This?</source>
        <translation>Vad är det här?</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
      <location filename="../src/gui/dialogs/qabstractpagesetupdialog.cpp" line="+68"/>
      <location line="+12"/>
      <source>Page Setup</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location filename="../src/gui/dialogs/qprintpreviewdialog.cpp" line="+252"/>
      <source>%1%</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+79"/>
      <source>Print Preview</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+29"/>
      <source>Next page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Previous page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>First page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Last page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+9"/>
      <source>Fit width</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Fit page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+11"/>
      <source>Zoom in</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Zoom out</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+6"/>
      <source>Portrait</source>
      <translation type="unfinished">Stående</translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Landscape</source>
      <translation type="unfinished">Liggande</translation>
    </message>
    <message>
      <location line="+10"/>
      <source>Show single page</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Show facing pages</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Show overview of all pages</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+15"/>
      <source>Print</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Page setup</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+1"/>
      <source>Close</source>
      <translation type="unfinished">Stäng</translation>
    </message>
    <message>
      <location line="+151"/>
      <source>Export to PDF</source>
      <translation type="unfinished"></translation>
    </message>
    <message>
      <location line="+3"/>
      <source>Export to PostScript</source>
      <translation type="unfinished"></translation>
    </message>
</context>
</TS>
